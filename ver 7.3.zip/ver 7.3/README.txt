MEMBERS:
Angeles, Marc Andrei D.(S11)
Dimacuangan, Aldwin Renzel P. (S11)
Ramos, Rafael Anton T. (S12)
Reyes, Ma. Julianna Re-an Dg. (S11)

INSTALL COMMANDS:
npm init
npm i express express-handlebars body-parser mongoose

DATABASE SETUP
create a database named "EspressoSelf" (without "")
create collections named "user", "cafe", "review"
import data from the appropriate .json files found in the "databases" folder


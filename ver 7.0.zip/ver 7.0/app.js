//Install Commands:
//npm init
//npm i express express-handlebars body-parser mongoose express-validator

const express = require('express');
const server = express();

const bodyParser = require('body-parser');
server.use(express.json()); 
server.use(express.urlencoded({ extended: true }));

const handlebars = require('express-handlebars');
server.set('view engine', 'hbs');
server.engine('hbs', handlebars.engine({
    extname: 'hbs'
}));

const {check, validationResult} = require('express-validator');

server.use(express.static('public'));

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/EspressoSelf');

// Database data
const userData = require('./databases/EspressoSelf.user.json');
const cafeData = require('./databases/EspressoSelf.cafe.json');
const reviewData = require('./databases/EspressoSelf.review.json');

const userSchema = new mongoose.Schema({
	username:{type: String},
	password:{type: String},
	email:{type: String},
	desc:{type: String},
	profile_pic:{type:String}
}, {versionKey: false});

const userModel = mongoose.model('user', userSchema);

const cafeSchema = new mongoose.Schema({
	name: {type: String},
	description: {type: String},
	rating: {type: Number},
	items: {type: Array},
	owner: {type: String},
	address: {type: String},
	price_range: {type: String},
	image_name: {type: String},
	cafe_id: {type: Number}
}, {versionKey: false});

const cafeModel = mongoose.model('shop', cafeSchema);

const reviewSchema = new mongoose.Schema({
	username: {type: String},
	cafe: {type: String},
	cafe_id: {type: Number},
	image_src: {type: String},
	rating: {type: Number},
	comment: {type: String},
	date: {type: String},
	isHelpful: {type: Number},
	isUnhelpful: {type: Number},
	owner_response: {type: String},
	isEdited: {type: Boolean}
}, {versionKey: false});

const reviewModel = mongoose.model('review', reviewSchema);

// Create Collections
userModel.createCollection().then(function (collection) {
	console.log('users Collection is created!');
})
cafeModel.createCollection().then(function (collection) {
	console.log('shops Collection is created!');
})
reviewModel.createCollection().then(function (collection) {
	console.log('reviews Collection is created!');
})

// Clear all existing documents from the collections then populate with data
userModel.deleteMany({}).then( function(err, result){
	for(var i = 0; i < userData.length; i++){
		new userModel({
			username	: userData[i].username,
			password	: userData[i].password,
			email		: userData[i].email,
			desc		: userData[i].desc,
			profile_pic	: userData[i].profile_pic
		}).save();
	}
});
cafeModel.deleteMany({}).then( function(err, result){
	for(var i = 0; i < cafeData.length; i++){
		new cafeModel({
			name		: cafeData[i].name,
			description	: cafeData[i].description,
			rating		: cafeData[i].rating,
			items		: cafeData[i].items,
			owner		: cafeData[i].owner,
			address		: cafeData[i].address,
			price_range	: cafeData[i].price_range,
			image_name	: cafeData[i].image_name,
			cafe_id		: cafeData[i].cafe_id
		}).save();
	}
});
reviewModel.deleteMany({}).then( function(err, result){
	for(var i = 0; i < reviewData.length; i++){
		new reviewModel({
			username		: reviewData[i].username,
			cafe			: reviewData[i].cafe,
			cafe_id			: reviewData[i].cafe_id,
			image_src		: reviewData[i].image_src,
			rating			: reviewData[i].rating,
			comment			: reviewData[i].comment,
			date			: reviewData[i].date,
			isHelpful		: reviewData[i].isHelpful,
			isUnhelpful		: reviewData[i].isUnhelpful,
			owner_response	: reviewData[i].owner_response,
			isEdited		: reviewData[i].isEdited
		}).save();
	}
});

// Track Logged User
global.loggedUser;

function errorFn(err){
    console.log('Error found. Please trace');
    console.error(err);
}

function successFn(err){
    console.log('Database query successful');
}



server.get('/', function(req, resp){
    cafeModel.find().lean().then(function(cafes){
		resp.render('body_home_nouser',{
			layout          : 'index',
			title           : 'Home - Espresso Self!',
			cafe			: cafes,
		});
	});
});

server.get('/body_home_nouser', function(req, resp){
    cafeModel.find().lean().then(function(cafes){
		resp.render('body_home_nouser',{
			layout          : 'index',
			title           : 'Home - Espresso Self!',
			cafe			: cafes,
		});
	});
});

server.get('/body_home_user', function(req, resp){
	cafeModel.find().lean().then(function(cafes){
		resp.render('body_home_user',{
			layout          : 'index',
			title           : 'Home - Espresso Self!',
			cafe			: cafes,
			user			: global.loggedUser,
		});
	});
});

server.post('/body_home_user', function(req, resp){
    const searchQuery = {username: req.body.user, password: req.body.pass};
    
    userModel.findOne(searchQuery).lean().then(function(val){
        console.log('Finding user');
        console.log('Inside: '+JSON.stringify(val));

        if(val != null){
			global.loggedUser = val;
			cafeModel.find().lean().then(function(cafes){
				resp.render('body_home_user',{
					layout          : 'index',
					title           : 'Home - Espresso Self!',
					cafe			: cafes,
					user            : val,
				});
			});
        }else{
            resp.render('login',{
                layout          : 'loginIndex',
                title           : 'Register - Espresso Self!',
            });
        }
    }).catch(errorFn);
});

server.get('/profile_user', function(req, resp){
	title = global.loggedUser.username.concat(" - Espresso Self!");
    
    const searchQuery = {username: global.loggedUser.username};
	
	reviewModel.find(searchQuery).lean().then((reviews) => {
		console.log(reviews);
		
		userModel.findOne(searchQuery).then(function(val){
			console.log('Finding user');
			console.log('Inside: '+JSON.stringify(val));
			
			if(val != null){
				resp.render('profile_user',{
					layout          : 'index',
					title           : title,
					user			: global.loggedUser,
					review			: reviews,
				});
			}
		}).catch(errorFn);
	});
});

server.get('/login', function(req, resp){ 
    resp.render('login',{
        layout          : 'loginIndex',
        title           : 'Register - Espresso Self!',
    });

});

server.get('/register', function(req, resp){
    resp.render('register',{
        layout          : 'loginIndex',
        title           : 'Register - Espresso Self!',
    });
	
	
});

server.post('/submitForm', function(req,resp){
	const searchQuery = {username: req.body.inputUsername};

	userModel.findOne(searchQuery).then(function(user){
		console.log('Creating user')
		if(user){
			resp.status(500).send("Username is already taken!");
		} else if(req.body.inputUsername === ""){
			resp.status(500).send("Username must not be empty!");
		} else if(req.body.inputEmail === ""){
			resp.status(500).send("Email must not be empty!");
		} else if(req.body.inputPassword === ""){
			resp.status(500).send("Password must not be empty!");
		} else if(req.body.inputPassword !== req.body.verify){
			resp.status(500).send("Passwords must match!");
		} else {
			const loginInstance = new userModel({
				username: req.body.inputUsername,
				password: req.body.inputPassword,
				email: req.body.inputEmail,
				desc: "",
				profile_pic: "Photos/profile_picture.webp"
			});
			loginInstance.save().then(function(login){
				console.log(loginInstance);
				console.log('User created');
				resp.render('login',{
					layout          : 'loginIndex',
					title           : 'Login - Espresso Self!',
				});
			}).catch(errorFn);
		}
	}).catch(errorFn);
});

server.get('/cafe1', function(req, resp){
    const searchQuery = {cafe_id: parseInt(req.query.cafe_id)};
	console.log(req.query.cafe_id);
    
    cafeModel.findOne(searchQuery).lean().then(function(data){
        console.log('Finding cafe');
        console.log('Inside: '+JSON.stringify(data));
		console.log('Data.name '+data.name);
		let name = data.name;
		let title = name.concat(" - Espresso Self!");
		
		const searchQuery2 = {cafe: data.name};
		
		reviewModel.find(searchQuery2).lean().then(function(reviews){
			resp.render('cafe1',{
				layout          : 'index',
				title           : title,
				cafe 			: data,
				review			: reviews
			});
		});
    }).catch(errorFn);
});

server.get('/cafe1_user', function(req, resp){
    const searchQuery = {cafe_id: parseInt(req.query.cafe_id)};
	console.log(req.query.cafe_id);
    
    cafeModel.findOne(searchQuery).lean().then(function(data){
        console.log('Finding cafe');
        console.log('Inside: '+JSON.stringify(data));
		console.log('Data.name '+data.name);
		let name = data.name;
		let title = name.concat(" - Espresso Self!");
		
		const searchQuery2 = {cafe: data.name};
		
		reviewModel.find(searchQuery2).lean().then(function(reviews){
			resp.render('cafe1_user',{
				layout          : 'index',
				title           : title,
				cafe 			: data,
				review			: reviews,
				user			: global.loggedUser
			});
		});
    }).catch(errorFn);
});

server.get('/add_review', function(req, resp){
	const searchQuery = {cafe_id : parseInt(req.query.cafe_id)};
	let cafe_id = req.query.cafe_id;

	cafeModel.findOne(searchQuery).lean().then(function(cafe){
		console.log('Finding cafe');
        console.log('Inside: '+JSON.stringify(cafe));
		console.log('cafe.name '+cafe.name);
		resp.render('add_edit_review',{
			layout          : 'index',
			title           : 'Create Review - Espresso Self!',
			user			: global.loggedUser,
			cafe_name		: cafe.name,
			cafe_id			: cafe_id,

		});
	})
});

server.post('/submitAdd', function(req, resp){
	const searchQuery = {cafe_id: parseInt(req.query.cafe_id)};
	let cafe_id = req.query.cafe_id;
	console.log(req.query.cafe_id);
    
    cafeModel.findOne(searchQuery).lean().then(function(cafe){
        console.log('Finding cafe');
        console.log('Inside: '+JSON.stringify(cafe));
		console.log('Data.name '+cafe.name);
		let name = cafe.name;
		let title = name.concat(" - Espresso Self!");

		console.log("Creating User")		
		const searchQuery2 = {cafe: cafe.name};
		
		reviewModel.find(searchQuery2).lean().then(function(reviews){
			const reviewInstance = new reviewModel({
				username		: global.loggedUser.username,
				cafe			: cafe.name,
				cafe_id			: cafe_id,
				image_src		: cafe.image_name,
				rating			: req.body.input_rating,
				comment			: req.body.input_review_body,
				date			: "04/04/24",
				isHelpful		: 0,
				isUnhelpful		: 0,
				owner_response	: "",
				isEdited		: false
			});
			reviewInstance.save().then(function(data){
				console.log(reviewInstance);
				console.log("User created");
				resp.render('cafe1_user',{
					layout          : 'index',
					title           : title,
					cafe 			: data,
					review			: reviews,
					user			: global.loggedUser
				});
			})
		});
    }).catch(errorFn);
});

server.get('/edit_profile', function(req, resp){
    resp.render('edit_profile',{
        layout          : 'index',
        title           : 'Edit Profile - Espresso Self!',
    });
});

server.get('/profile', function(req, resp){
	title = global.loggedUser.username.concat(" - Espresso Self!");
    resp.render('profile',{
        layout          : 'index',
        title           : title,
    });
});

function finalClose(){
    console.log('Close connection at the end!');
    mongoose.connection.close();
    process.exit();
}

const port = process.env.PORT | 3000; //required to use port 3000
server.listen(port, function(){
    console.log('Listening at port '+port);
});
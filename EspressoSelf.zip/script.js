var username = "";
var password = "";
var address = "";
var isLoggedIn = false;

function setUsername(name){
  username = name;
}

function setPassword(pass){
  password = pass;
}

function setAddress(email){
  address = email;
}

function login(name, pass){
  if((name == username) && (pass == password)){
    isLoggedIn = true;
  }
}
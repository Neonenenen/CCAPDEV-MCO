//Install Commands:
//npm init
//npm i express express-handlebars body-parser mongodb mongoose express-validator

const express = require('express');
const server = express();

const bodyParser = require('body-parser')
server.use(express.json()); 
server.use(express.urlencoded({ extended: true }));

const handlebars = require('express-handlebars');
server.set('view engine', 'hbs');
server.engine('hbs', handlebars.engine({
    extname: 'hbs'
}));

const {check, validationResult} = require('express-validator');

server.use(express.static('public'));

const { MongoClient } = require('mongodb');
const databaseURL = "mongodb://127.0.0.1:27017/";
const mongoClient = new MongoClient(databaseURL);

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/')


const databaseName = "EspressoSelf";
const collectionName1 = "user";
const collectionName2 = "cafe";
const collectionName3 = "review";

const userSchema = new mongoose.Schema({
	username:{type: String},
	password:{type: String},
	email:{type: String},
	desc:{type: String},
}, {versionKey: false});

const userModel = mongoose.model('user', userSchema);

const cafeSchema = new mongoose.Schema({
	name: {type: String},
	description: {type: String},
	items: {type: Array},
	owner: {type: String},
	address: {type: String},
	price_range: {type: String},
	image_name: {type: String},
}, {versionKey: false});

const cafeModel = mongoose.model('cafe', cafeSchema);

const reviewSchema = new mongoose.Schema({
	username: {type: String},
	rating: {type: Number},
	comment: {type: String},
	isHelpful: {type: Number},
	isUnhelpful: {type: Number},
}, {versionKey: false});

const reviewModel = mongoose.model('review', reviewSchema);

global.loggedUser;

function errorFn(err){
    console.log('Error found. Please trace');
    console.error(err);
}

function successFn(err){
    console.log('Database query successful');
}

mongoClient.connect().then(function(con){
    console.log("Attempt to create...");
    const dbo = mongoClient.db(databaseName);
    dbo.createCollection(collectionName1).then(successFn).catch(errorFn);
    dbo.createCollection(collectionName2).then(successFn).catch(errorFn);
    dbo.createCollection(collectionName3).then(successFn).catch(errorFn);
}).catch(errorFn);


server.get('/', function(req, resp){
	const dbo = mongoClient.db(databaseName);
    const col = dbo.collection(collectionName2);
    
    col.find().toArray().then((cafes) => {
		resp.render('body_home_nouser',{
			layout          : 'index',
			title           : 'Home - Espresso Self!',
			cafe			: cafes,
		});
	});
});

server.get('/body_home_nouser', function(req, resp){
    const dbo = mongoClient.db(databaseName);
    const col = dbo.collection(collectionName2);
    
    col.find().toArray().then((cafes) => {
		resp.render('body_home_nouser',{
			layout          : 'index',
			title           : 'Home - Espresso Self!',
			cafe			: cafes,
		});
	});
});

server.get('/body_home_user', function(req, resp){
	const dbo = mongoClient.db(databaseName);
    const col = dbo.collection(collectionName2);
    
    col.find().toArray().then((cafes) => {
		resp.render('body_home_user',{
			layout          : 'index',
			title           : 'Home - Espresso Self!',
			cafe			: cafes,
			user			: global.loggedUser,
		});
	});
});

server.post('/body_home_user', function(req, resp){	
    const dbo = mongoClient.db(databaseName);
    const col = dbo.collection(collectionName1);
    const col2 = dbo.collection(collectionName2);
    
    const searchQuery = {username: req.body.user, password: req.body.pass};
    let username = req.body.user;
    
    col.findOne(searchQuery).then(function(val){
        console.log('Finding user');
        console.log('Inside: '+JSON.stringify(val));

        if(val != null){
			global.loggedUser = username;
			col2.find().toArray().then((cafes) => {
				resp.render('body_home_user',{
					layout          : 'index',
					title           : 'Home - Espresso Self!',
					cafe			: cafes,
					user            : username,
					profile_pic		: val.profile_pic,
				});
			});
        }else{
            resp.render('login',{
                layout          : 'loginIndex',
                title           : 'Register - Espresso Self!',
            });
        }
    }).catch(errorFn);
});

server.get('/profile_user', function(req, resp){
	title = global.loggedUser.concat(" - Espresso Self!");
	const dbo = mongoClient.db(databaseName);
    const col = dbo.collection(collectionName1);
	const col2 = dbo.collection(collectionName3);
    
    const searchQuery = {username: global.loggedUser};
	
	col2.find(searchQuery).toArray().then((reviews) => {
		console.log(reviews);
		
		col.findOne(searchQuery).then(function(val){
			console.log('Finding user');
			console.log('Inside: '+JSON.stringify(val));
			
			if(val != null){
				resp.render('profile_user',{
					layout          : 'index',
					title           : title,
					user			: global.loggedUser,
					description		: val.desc,
					cafes			: val.cafes,
					review			: reviews,
					profile_pic		: val.profile_pic,
				});
			}
		}).catch(errorFn);
	});
});

server.get('/login', function(req, resp){
	
    resp.render('login',{
        layout          : 'loginIndex',
        title           : 'Register - Espresso Self!',
    });

});

server.get('/register', function(req, resp){
    resp.render('register',{
        layout          : 'loginIndex',
        title           : 'Register - Espresso Self!',
    });
	
	
});
server.post('/submitForm', [
	check('inputUsername').notEmpty().withMessage('Username must not be empty'),
	check('inputEmail').notEmpty().withMessage('Email must not be empty'),
	check('inputPassword').notEmpty().withMessage('Password must not be empty'),
	check('verify').notEmpty().withMessage('Verifying password must not be empty'),
	check('inputPassword').equals('verify').withMessage('Passwords must match'),
],async function(req,resp){

	const dbo = mongoClient.db(databaseName);
	const userCol = dbo.collection(collectionName1);

	const inputUsername = req.body.name;
	const inputPassword = req.body.password;
	const inputEmail = req.body.email;
	const defaultDesc = "BIO TO BE MADE";
	const verify = req.body.verify;

	const errors = validationResult(req);
	console.log(errors);

	const temp = {
		username: inputUsername,
		password: inputPassword,
		email: inputEmail,
		desc: defaultDesc,
		profile_pic: "Photos/profile_picture.webp"
	};

	if(errors.isEmpty() && inputPassword == verify){
		try{
			console.log(temp);

			userCol.insertOne(temp).then(function(login){
				console.log('User created');
			});
			resp.render('login',{
				layout          : 'loginIndex',
				title           : 'Register - Espresso Self!',
			});
		}catch(error){
			console.error('Error saving user:', error);
      		resp.status(500).send('Error saving user'); // Send an error response
		}
	}
	else{
		resp.status(400).send('There is an error in your input, please go back and try again'); // Send a bad request response
	}
});



server.get('/add_cafe', function(req, resp){
    resp.render('add_cafe',{
        layout          : 'index',
        title           : 'Add Cafe - Espresso Self!',
		user			: global.loggedUser,
    })
});

server.get('/cafe1', function(req, resp){
	const dbo = mongoClient.db(databaseName);
    const col = dbo.collection(collectionName2);
	const col2 = dbo.collection(collectionName3);
    
    const searchQuery = {cafe_id: parseInt(req.query.cafe_id)};
	console.log(req.query.cafe_id);
    
    col.findOne(searchQuery).then(function(data){
        console.log('Finding cafe');
        console.log('Inside: '+JSON.stringify(data));
		console.log('Data.name '+searchQuery.name);
		let name = searchQuery.name;
		let title = name.concat(" - Espresso Self!");
		
		const searchQuery2 = {cafe: data.name};
		
		col2.find(searchQuery2).toArray().then((reviews) => {
			resp.render('cafe1',{
				layout          : 'index',
				title           : title,
				name 			: data.name,
				address			: data.address,
				price_range		: data.price_range,
				description		: data.description,
				items			: data.items,
				image_src		: data.image_src,
				review			: reviews
			});
		});
    }).catch(errorFn);
});

server.get('/cafe1_user', function(req, resp){
    const dbo = mongoClient.db(databaseName);
    const col = dbo.collection(collectionName2);
	const col2 = dbo.collection(collectionName3);
    
    const searchQuery = {cafe_id: parseInt(req.query.cafe_id)};
	let cafe_id = req.query.cafe_id;
	console.log(req.query.cafe_id);
    
    col.findOne(searchQuery).then(function(data){
        console.log('Finding cafe');
        console.log('Inside: '+JSON.stringify(data));
		
		let name = data.name;
		let title = name.concat(" - Espresso Self!");
		
		const searchQuery2 = {cafe: data.name};
		
		col2.find(searchQuery2).toArray().then((reviews) => {
			resp.render('cafe1_user',{
				layout          : 'index',
				title           : title,
				name 			: data.name,
				address			: data.address,
				price_range		: data.price_range,
				description		: data.description,
				items			: data.items,
				image_src		: data.image_src,
				cafe_id			: cafe_id,
				review			: reviews,
				user			: global.loggedUser,
			});
		});
    }).catch(errorFn);
});

server.get('/add_edit_review', function(req, resp){
    resp.render('add_edit_review',{
        layout          : 'index',
        title           : 'Create Review - Espresso Self!',
		user			: global.loggedUser,
		cafe_id			: req.query.cafe_id,
    });
});

server.get('/edit_profile', function(req, resp){
    resp.render('edit_profile',{
        layout          : 'index',
        title           : 'Edit Profile - Espresso Self!',
    });
});

server.get('/profile', function(req, resp){
	title = global.loggedUser.concat(" - Espresso Self!");
    resp.render('profile',{
        layout          : 'index',
        title           : title,
    });
});

function finalClose(){
    console.log('Close connection at the end!');
    mongoClient.close();
    process.exit();
}

const port = process.env.PORT | 3000; //required to use port 3000
server.listen(port, function(){
    console.log('Listening at port '+port);
});